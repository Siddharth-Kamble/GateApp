const String apiBase = 'https://api.mygate.example.com';
